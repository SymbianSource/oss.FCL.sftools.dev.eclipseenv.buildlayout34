package org.eclipse.dd.debug.memory.renderings.traditional;

public interface IMemoryByte {

	public boolean isEdited();
	
	public void setEdited(boolean edited);
}
