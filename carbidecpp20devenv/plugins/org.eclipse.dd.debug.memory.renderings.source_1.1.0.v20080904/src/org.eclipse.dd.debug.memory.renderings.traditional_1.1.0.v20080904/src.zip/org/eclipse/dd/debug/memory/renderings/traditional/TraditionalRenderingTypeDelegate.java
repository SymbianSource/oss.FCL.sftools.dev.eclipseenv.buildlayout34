/*******************************************************************************
 * Copyright (c) 2006 Wind River Systems, Inc. and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Ted R Williams (Wind River Systems, Inc.) - initial implementation
 *     
 *******************************************************************************/

package org.eclipse.dd.debug.memory.renderings.traditional;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.ui.memory.IMemoryRendering;
import org.eclipse.debug.ui.memory.IMemoryRenderingTypeDelegate;

public class TraditionalRenderingTypeDelegate 
	implements IMemoryRenderingTypeDelegate 
{

	public IMemoryRendering createRendering(String id) throws CoreException {
		return new TraditionalRendering(id);
	}


}
